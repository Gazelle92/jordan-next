export type User = {
  name: string;
  instagram: string;
  phone: string;
};
